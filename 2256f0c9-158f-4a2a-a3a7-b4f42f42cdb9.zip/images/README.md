# Images du Site

Ce dossier contient les images utilisées sur le site GrillesPointsDeCroix.

## Instructions pour les Images

### Images de Produits
- **produit1.jpg** - Rose Classique (remplacer par une vraie image)
- **produit2.jpg** - Chat Mignon (remplacer par une vraie image)
- **produit3.jpg** - Montagne Alpes (remplacer par une vraie image)
- **produit4.jpg** - Tulipes Printemps (remplacer par une vraie image)
- **produit5.jpg** - Chouette Hibou (remplacer par une vraie image)
- **produit6.jpg** - Étoiles Déco (remplacer par une vraie image)
- **produit7.jpg** - Coucher de Soleil (remplacer par une vraie image)
- **produit8.jpg** - Cœurs Amour (remplacer par une vraie image)

### Recommandations pour les Images

1. **Taille** : 800x600 pixels minimum (formats carrés 800x800 recommandés)
2. **Format** : JPG ou PNG
3. **Compression** : Utilisez TinyPNG ou Squoosh pour compresser
4. **Noms** : Utilisez des noms descriptifs avec des tirets
5. **Alt text** : Toujours inclure un attribut alt descriptif

### Sources d'Images Gratuits

- **Unsplash** : https://unsplash.com
- **Pexels** : https://www.pexels.com
- **Pixabay** : https://pixabay.com
- **Canva** : https://www.canva.com

### Création d'Images Personnalisées

Pour créer vos propres grilles de points de croix :

1. Utilisez des logiciels spécialisés :
   - PCStitch (payant)
   - KG-Chart (gratuit)
   - StitchSketch (gratuit)

2. Exportez en haute résolution
3. Ajoutez une légende avec les codes DMC/Anchor
4. Sauvegardez en PDF et PNG

### Images pour les Réseaux Sociaux

- **og-image.jpg** : 1200x630 pixels (Open Graph)
- **twitter-image.jpg** : 1200x600 pixels (Twitter Card)
- **favicon.ico** : 32x32 ou 16x16 pixels

## Note Actuelle

Les emojis sont utilisés comme placeholders dans le code HTML.
Remplacez-les par de vraies images pour un aspect professionnel.